<?php
	//ī�װ��� ��
	$arrayCategory = array();
	$categoryResult = $db->query("Select id, parent_id, level, title, category_code From fm_category where level >= 2 order by level, parent_id, id asc");
	while ($categoryRow = $db->fetch($categoryResult, 1)) {
		if ($categoryRow['level'] == '2') {
			$arrayCategory[$categoryRow['category_code']] = array($categoryRow['title']);
		} else if ($categoryRow['level'] == '3') {
			$firstCategory = substr($categoryRow['category_code'], 0, 4);
			$arrayCategory[$categoryRow['category_code']] = array($arrayCategory[$firstCategory][0], $categoryRow['title']);
		} else if ($categoryRow['level'] == '4') {
			$secondCategory = substr($categoryRow['category_code'], 0, 8);
			$arrayCategory[$categoryRow['category_code']] = array($arrayCategory[$secondCategory][0], $arrayCategory[$secondCategory][1], $categoryRow['title']);
		}
		setCategoryBrand($arrayCategory[$categoryRow['category_code']]);
	}

	//ī�װ��� ��ũ
	$arrayCategoryLink = array();
	$categoryLinkResult = $db->query("Select * From fm_category_link order by goods_seq, category_link_seq asc");
	while ($categoryLinkRow = $db->fetch($categoryLinkResult, 1)) {
		$arrayCategoryLink[$categoryLinkRow['goods_seq']][] = $arrayCategory[$categoryLinkRow['category_code']];
	}

	$arrayBrand = array();
	$brandResult = $db->query("Select id, parent_id, level, title, category_code From fm_brand where level >= 2 order by level, parent_id, id asc");
	while ($brandRow = $db->fetch($brandResult, 1)) {
		if ($brandRow['level'] == '2') {
			$arrayBrand[$brandRow['category_code']] = array($brandRow['title']);
		} else if ($brandRow['level'] == '3') {
			$arrayBrand[$brandRow['category_code']] = array($arrayBrand[substr($brandRow['category_code'], 0, 4)][0], $brandRow['title']);
		} else if ($brandRow['level'] == '4') {
			$arrayBrand[$brandRow['category_code']] = array($arrayBrand[substr($brandRow['category_code'], 0, 8)][0], $arrayBrand[substr($brandRow['category_code'], 0, 8)][1], $brandRow['title']);
		}
		setCategoryBrand($arrayBrand[$brandRow['category_code']], 'brand');
	}

	$arrayBrandLink = array();
	$brandLinkResult = $db->query("Select goods_seq, category_code From fm_brand_link order by goods_seq, category_link_seq asc");
	while ($brandLinkRow = $db->fetch($brandLinkResult, 1)) {
		preg_match('/[[:digit:]]{4,12}/', $brandLinkRow['category_code'], $codeResult);
		if (!empty($codeResult) && !$arrayBrandLink[$brandLinkRow['goods_seq']]) {
			if (!empty($arrayBrand[$brandLinkRow['category_code']])) {
				$arrayBrandLink[$brandLinkRow['goods_seq']] = $brandLinkRow['category_code'];
			}
		}
	}
	

	//������, ������, �귣��, �𵨸�
	$arrayAddition = array();
	$arrayAdditionExtraInfo = array();
	$additionResult = $db->query("Select * From fm_goods_addition order by goods_seq, addition_seq asc");
	while ($additionRow = $db->fetch($additionResult, 1)) {
		if ($additionRow['type'] == 'direct' || $additionRow['type'] == 'brand') {
			$arrayAdditionExtraInfo[$additionRow['goods_seq']][] = array($additionRow['title'], $additionRow['contents']);
		}
		else {
			$arrayAddition[$additionRow['goods_seq']][$additionRow['type']] = $additionRow['contents'];
		}
	}

	//��ǰ �̹���
	$arrayGoodsImg = array();
	$goodsImgResult = $db->query("Select * From fm_goods_image where image_type in ('large', 'view', 'list1', 'list2') order by goods_seq, image_type, cut_number asc");
	while ($goodsImgRow = $db->fetch($goodsImgResult, 1)) {
		if ($goodsImgRow['image_type'] == 'large' || $goodsImgRow['image_type'] == 'view') {
			$arrayGoodsImg[$goodsImgRow['goods_seq']][$goodsImgRow['image_type']][$goodsImgRow['cut_number']] = $goodsImgRow['image'];
		} else {
			if ($goodsImgRow['cut_number'] == '1') {
				$arrayGoodsImg[$goodsImgRow['goods_seq']][$goodsImgRow['image_type']] = $goodsImgRow['image'];
			}
		}
	}

	//��ǰ �ɼ�
	$arrayGoodsOption = array();
	$goodsOptionResult = $db->query("Select option_seq, goods_seq, default_option, option_title, option1, option2, option3, option4, option5, consumer_price, price From fm_goods_option order by goods_seq, option_seq asc");
	while ($goodsOptionRow = $db->fetch($goodsOptionResult, 1)) {
		$arrayGoodsOption[$goodsOptionRow['goods_seq']][] = $goodsOptionRow;
	}

	//��ǰ ���
	$arrayGoodsStock = array();
	$goodsStockResult = $db->query("Select goods_seq, option_seq, stock From fm_goods_supply order by goods_seq, option_seq asc");
	while ($goodsStockRow = $db->fetch($goodsStockResult, 1)) {
		$arrayGoodsStock[$goodsStockRow['goods_seq']][$goodsStockRow['option_seq']] = $goodsStockRow['stock'];
	}

	//����ɼ� => �߰���ǰ������
	$arraySubOption = array();
	$subOptionResult = $db->query("Select goods_seq, sub_required, suboption_title, suboption, price From fm_goods_suboption order by goods_seq, suboption_seq asc");
	while ($subOptionRow = $db->fetch($subOptionResult, 1)) {
		$arraySubOption[$subOptionRow['goods_seq']][$subOptionRow['suboption_title']][] = $subOptionRow;
	}

	$arrayGoodsRelated = array();
	$goodsRelatedResult = $db->query("Select goods_seq, relation_goods_seq From fm_goods_relation order by goods_seq, relation_seq");
	while ($goodsRelatedRow = $db->fetch($goodsRelatedResult, 1)) {
		$arrayGoodsRelated[$goodsRelatedRow['goods_seq']][] = $goodsRelatedRow['relation_goods_seq'];
	}
?>