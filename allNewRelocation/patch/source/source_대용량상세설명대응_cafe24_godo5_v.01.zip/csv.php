<?
setlocale(LC_CTYPE, "ko_KR.eucKR");
?>
<html>
<head>
	<title>CSV Viewer</title>
	<style>
		table {border-collapse:collapse;}
		td {border:1px solid d6d6d6;}
		textarea {height:30px;border:0px;overflow:auto;}
		body,select,input,td,textarea {font-size:8pt;font-family:dotum;}
		input {height:20px;border:1px solid #e5e5e5;}

		.fl {float:left;}
		.b {font-weight:bold;}
		.numberBar{font-weight:bold;height:25px;background-color:#f0f0f0;}
		.leftNum{font-weight:bold;padding:0 10px 0 10px;background-color:#f0f0f0;}

		#param .title{width:60px;text-align:center;}
	</style>
</head>
<body>
	<form>
		<table id="param">
			<tr>
				<td class="title">���ϸ�</td>
				<td>
					<input type="text" name="filename" value="<?=$_GET['filename']?>" />
					<?
						$dir=opendir("./");
						while($row = readdir($dir)) {
							if(in_array(substr($row,-4),array(".csv",".txt")))
								$file[]=$row;
						}
						closedir($dir);

						if(count($file)){
							echo "<select onchange=\"document.all.filename.value=this.value\">";
							echo "<option value=\"\">==�����Է�==</option>";
							foreach($file as $value){
								echo "<option value=".$value.">".$value."</option>";
							}
							echo "</select>";
						}	
					?>
				</td>
				
			
				<td class="title">������</td>
				<td><input type="text" name="separater" value="<?=$_GET['separater']?$_GET['separater']:"	"?>" />
					<select onchange="document.all.separater.value=this.value;">
					<option value="">==����==</option>
					<option value=",">�޸�</option>
					<option value=".">��</option>
					<option value="	">��</option>
					</select>
				</td>

				<td class="title">��°���</td>
				<td><input type="text" name="displayline" value="<?=($_GET['displayline']) ? $_GET['displayline'] : '100' ?>" /></td>

				<td rowspan="2" valign="bottom"><input type="submit" value="Ȯ��" /></td>
			</tr>
		</table>
	</form>

	<?
		if($_GET['filename']){

			$filename=$_GET['filename'];
			
			$displayline=$_GET['displayline'];
			
			$separater=$_GET['separater']?$_GET['separater']:",";
		
			if(!file_exists($filename)){
				echo $filename." ������ �������� �ʽ��ϴ�.<br ><a href='#' onclick=\"history.go(-1)\">�ڷ�</a>";
			}
			else{
				if($displayline<0)	$displayline=0;

				$fp = fopen($filename, 'r' );

				$fields = fgetcsv( $fp, 135000, $separater );

				$cols = count($fields);

				$cnt=0;

				echo "<table>";

				do{

					//ĭ��ȣ ���� ���
					if($cnt==0 || (($cnt-1)%20==0) && $cnt>1){

						echo "<tr class='numberBar'>";

							echo "<td></td>";

							for($i=0;$i<$cols;$i++)	echo "<td align=center>".$i."</td>";

						echo "</tr>";

					}
					
					//������ ���� ���
					echo "<tr>";

						echo "<td class='leftNum'>".$cnt."</td>";

						for($i=0;$i<$cols;$i++){

							echo "<td>";

								if($fields[$i]=='') echo "&nbsp;";
								else {
									
									$width=strlen($fields[$i])*8;

									if($width>150)$width=150;

									if($width<10)$width=20;

									echo "<textarea style=\"width:".$width."\">$fields[$i]</textarea>";

								}

							echo "</td>";

						}

					echo "</tr>";
					
					//��°����� ���� �����ֱ�
					if($displayline && $cnt>=$displayline)break;

					$cnt++;

				}while($fields = fgetcsv( $fp, 1350000, $separater ));

				echo "</table>";
				echo "<br ><br >$cnt Lines";
			}
		}
	?>
</body>
</html>