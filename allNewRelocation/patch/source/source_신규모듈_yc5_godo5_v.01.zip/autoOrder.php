<?php
	include '../../inc/header.php';
	setlocale(LC_CTYPE, 'ko_KR.eucKR');

if($_POST['m']=="start") {
	$relocationData = $_POST['relocationData'];
	$url = $_POST['afterUrl'];
	$dumpFileName = $_POST['dumpFileName'];		// ���̱׷��̼� �������ϸ�
?>
<script>
	function prograss_up(cnt){
		document.getElementById('prograssbar').value = cnt;
		document.getElementById('status').innerHTML = cnt;
	}
	function itemPrograss_up(itemCnt){
		document.getElementById('itemPrograss_up').value = itemCnt;
		document.getElementById('itemStatus').innerHTML = itemCnt;
	}
	function cancelPrograss_up(cancelCnt){
		document.getElementById('cancelPrograss_up').value = cancelCnt;
		document.getElementById('cancelStatus').innerHTML = cancelCnt;
	}
	function emoneyPrograss_up(emoneyCnt){
		document.getElementById('emoneyPrograss_up').value = emoneyCnt;
		document.getElementById('emoneyStatus').innerHTML = emoneyCnt;
	}

	function status(data){
		document.getElementById('prograssbar').max = data;
		document.getElementById('total').innerHTML = data;
	}
	function itemStatus(itemData){
		document.getElementById('itemPrograss_up').max = itemData;
		document.getElementById('itemTotal').innerHTML = itemData;
	}
	function cancelStatus(cancelData){
		document.getElementById('cancelPrograssbar').max = cancelData;
		document.getElementById('cancelTotal').innerHTML = cancelData;
	}
	function status(emoneyData){
		document.getElementById('emoneyPrograssbar').max = emoneyData;
		document.getElementById('emoneyTotal').innerHTML = emoneyData;
	}
</script>
<p><strong>ũ��/���̾�����/�����</strong>���� ���� �۾��� ���� �Ͻø� ����ȭ�� HTML5 ���α׷����ٷ� ������¸� Ȯ�� �� �� �ֽ��ϴ�.</p>

	<progress id="prograssbar" value="0" max="100" style="width:500px;"><strong>�ֹ� Progress : <span id="status">0</span>/<span id="total"></span></strong></progress><br/>
	<progress id="itemPrograss_up" value="0" max="100" style="width:500px;"><strong>�ֹ� ������ Progress : <span id="itemStatus">0</span>/<span id="itemTotal"></span></strong></progress><br/>
	<progress id="cancelPrograss_up" value="0" max="100" style="width:500px;"><strong>��� Progress : <span id="cancelStatus">0</span>/<span id="cancelTotal"></span></strong></progress><br/>
	<progress id="emoneyPrograss_up" value="0" max="100" style="width:500px;"><strong>������ Progress : <span id="emoneyStatus">0</span>/<span id="emoneyTotal"></span></strong></progress><br/>
	<?
		$arrayDataQuery = array();
		//--- �ֹ� ���̺� �ʱ�ȭ

		$db->query('DROP TABLE IF EXISTS `tmp_orderno`;');
			$db->query("CREATE TABLE IF NOT EXISTS `tmp_orderno` (
								`sno` int(10) NOT NULL AUTO_INCREMENT,
								`originalOrderNo` char(200) NOT NULL,
								`godo5OrderNo` char(200) NOT NULL,
								`orderGoodsRegDt` datetime NOT NULL,
								`regDt` datetime NOT NULL,
								PRIMARY KEY (`sno`),
								KEY `originalOrderNo` (`originalOrderNo`),
								KEY `godo5OrderNo` (`godo5OrderNo`)
							) ENGINE=MyISAM DEFAULT CHARSet=euckr AUTO_INCREMENT=1;");
			
		//------------------------------------------------------
		// - Advice - �ӽ� ��ȯ ���̺� �ֹ���ȣ ����
		//------------------------------------------------------
		$arrayGetOrderTempNo = array(
			'mode'		=> 'getRelocationOrderTempNo',
		);
		$getOrderTempNoReault = xmlUrlRequest('http://' . $url . '/main/relocation.php', $arrayGetOrderTempNo);
		$arrayGodo5OrderNo		= array();
		$arrayOrderGoodsRegDt	= array();
		if ($getOrderTempNoReault->tempOrderNoResult) {
			foreach ($getOrderTempNoReault->godo5OrderNo as $godo5OrderNo) {
				$arrayGodo5OrderNo[(string)$godo5OrderNo->attributes()->originalOrderNo] = (string)$godo5OrderNo;
				$Proc_Query = "Insert Into `tmp_orderno` (originalOrderNo, godo5OrderNo, orderGoodsRegDt, regDt) Values ('".(string)$godo5OrderNo->attributes()->originalOrderNo."','".(string)$godo5OrderNo."','" . (string)$godo5OrderNo->attributes()->orderGoodsRegDt . "','".date('Y-m-d H:i:s')."')";
				$db->query($Proc_Query);
				$arrayOrderGoodsRegDt[(string)$godo5OrderNo->attributes()->originalOrderNo] = (string)$godo5OrderNo->attributes()->orderGoodsRegDt;
			}
		}

		$arrayMemberCheckPostData			= array();			// ���� �� ���θ� ȸ�� ������ üũ
		$arrayMemberCheckPostData['mode']	= 'memberCheck';	//ó�� ���μ��� �⺻ ��� �� ����
		$arrayMemberCheckPostData['memberDeleteFlag']	= 0;	//ó�� ���μ��� �⺻ ��� �� ����

		$object = xmlUrlRequest("http://" . $url . "/main/relocation.php", $arrayMemberCheckPostData);
		$memberData = $object->memberData;

		$arrayMember = array();
		foreach($memberData as $value) {
			$newMno = (int)$value->attributes()->memNo;
			$arrayMember[urldecode((string)$value)] = $newMno;
		}

		$arrayOrderInsertData = array();
		if(@in_array("order", $relocationData) && file_exists("order.csv")) {
			$arrayDataQuery[] =  'TRUNCATE TABLE es_order;';
			$arrayDataQuery[] =  'TRUNCATE TABLE es_orderGoods;';
			$arrayDataQuery[] =  'TRUNCATE TABLE es_orderInfo;';
			$arrayDataQuery[] =  'TRUNCATE TABLE es_orderDelivery;';
			//------------------------------------------------------
			//------------------------------------------------------
			// - Advice - ��� �� ȸ�� ���� ����
			//------------------------------------------------------
			

			$orderCnt = 0;
			$itemCnt = 0;
			$cancelCnt = 0;
			$emoneyCnt = 0;
			$iCno = 0;

			$fp = fopen("order.csv", 'r' );
			$fields = fgetcsv( $fp, 135000, "," );
			while($orderDataRow = fgetcsv( $fp, 135000, "," )) {
				$esOrderGoods = array();

				$oldOrderNo = $orderDataRow[0]; // ���� �ֹ���ȣ
				$esOrddt	= ordnoDateTypeSetting($orderDataRow[1]);	// �ֹ���
				if ($arrayGodo5OrderNo[$oldOrderNo]) {
					$esOrderNo = $arrayGodo5OrderNo[$oldOrderNo];
				}
				else {
					$esOrderNo = getGodomall5Ordno($esOrddt);		// �ű� �ֹ���ȣ
					$arrayGodo5OrderNo[$oldOrderNo] = $esOrderNo;
					$arrayOrderGoodsRegDt[$oldOrderNo] = $esOrddt;
					//�ֹ���ȣ ���� ���� �ӽ� ���̺� ����
					$Proc_Query = "Insert Into `tmp_orderno` (originalOrderNo, godo5OrderNo, orderGoodsRegDt, regDt) Values ('".$oldOrderNo."','".$esOrderNo."','" . $esOrddt . "','".date('Y-m-d H:i:s')."')";
					$db->query($Proc_Query);
				}

				$SettlePrice = '';		// ��ǰ, ��ۺ� �հ� �ݾ�
				$totalGoodsPrice = '';			// ��ǰ �հ�ݾ�
				$totalDeliveryCharge = '';			// ��ۺ�
				$totalMemberDcPrice = '';			// ȸ�� ���ΰ� ����
				$totalMileage = '';				// ���������
				$totalCouponOrderDcPrice = '';				// �����ݾ�
				$invoiceNo = '';		// �����ȣ

				

				$arrayOrderInsertData[$esOrderNo]['orderNo'] = $esOrderNo;
				$arrayOrderInsertData[$esOrderNo]['memNo'] = $arrayMember[$orderDataRow[4]]; //ȸ�� �Ϸù�ȣ
				$arrayOrderInsertData[$esOrderNo]['orderStatus'] = $orderDataRow[22];
				$arrayOrderInsertData[$esOrderNo]['orderIp'] = $orderDataRow[39];
				$arrayOrderInsertData[$esOrderNo]['orderChannelFl'] ='shop';
				$arrayOrderInsertData[$esOrderNo]['orderTypeFl'] =	$orderDataRow[2];		//�ֹ� Ÿ��
				$arrayOrderInsertData[$esOrderNo]['orderEmail'] = $orderDataRow[23];
				$arrayOrderInsertData[$esOrderNo]['orderGoodsNm'] ='';
				$arrayOrderInsertData[$esOrderNo]['orderGoodsCnt'] ='';
				$arrayOrderInsertData[$esOrderNo]['SettlePrice'] = $orderDataRow[19];
				//$arrayOrderInsertData[$esOrderNo]['taxSupplyPrice'] ='';
				//$arrayOrderInsertData[$esOrderNo]['taxVatPrice'] ='';
				//$arrayOrderInsertData[$esOrderNo]['taxFreePrice'] ='';
				//$arrayOrderInsertData[$esOrderNo]['realTaxSupplyPrice'] ='';
				//$arrayOrderInsertData[$esOrderNo]['realTaxVatPrice'] ='';
				//$arrayOrderInsertData[$esOrderNo]['realTaxFreePrice'] ='';
				$arrayOrderInsertData[$esOrderNo]['useMileage'] = $orderDataRow[29];
				//$arrayOrderInsertData[$esOrderNo]['useDeposit'] =''; //��ġ��
				$arrayOrderInsertData[$esOrderNo]['totalGoodsPrice'] = $orderDataRow[20]; //�� ��ǰ
				$arrayOrderInsertData[$esOrderNo]['totalDeliveryCharge'] = $orderDataRow[21]; // �� ��ۺ�
				//$arrayOrderInsertData[$esOrderNo]['totalGoodsDcPrice'] = '';
				$arrayOrderInsertData[$esOrderNo]['totalMemberDcPrice'] = $orderDataRow[32];
				//$arrayOrderInsertData[$esOrderNo]['totalMemberOverlapDcPrice'] = '';
				//$arrayOrderInsertData[$esOrderNo]['totalCouponGoodsDcPrice'] = '';
				$arrayOrderInsertData[$esOrderNo]['totalCouponOrderDcPrice'] = $orderDataRow[31];
				//$arrayOrderInsertData[$esOrderNo]['totalCouponDeliveryDcPrice'] ='';
				$arrayOrderInsertData[$esOrderNo]['totalMileage'] = $orderDataRow[30];
				//$arrayOrderInsertData[$esOrderNo]['totalGoodsMileage'] ='';
				//$arrayOrderInsertData[$esOrderNo]['totalMemberMileage'] = '';
				//$arrayOrderInsertData[$esOrderNo]['totalCouponGoodsMileage'] ='';
				//$arrayOrderInsertData[$esOrderNo]['totalCouponOrderMileage'] ='';
				//$arrayOrderInsertData[$esOrderNo]['mileageGiveExclude'] ='';
				//$arrayOrderInsertData[$esOrderNo]['minusDepositFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['minusRestoreDepositFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['minusMileageFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['minusRestoreMileageFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['plusMileageFl'] = '';
				//$arrayOrderInsertData[$esOrderNo]['plusRestoreMileageFl'] = '';
				//$arrayOrderInsertData[$esOrderNo]['firstSaleFl'] = 'y';
				//$arrayOrderInsertData[$esOrderNo]['sendMailSmsFl'] = '';
				$arrayOrderInsertData[$esOrderNo]['SettleKind'] = $orderDataRow[18];
				$arrayOrderInsertData[$esOrderNo]['bankAccount'] = $orderDataRow[33];
				$arrayOrderInsertData[$esOrderNo]['bankSender'] = $orderDataRow[34];
				//$arrayOrderInsertData[$esOrderNo]['receiptFl'] = '';
				//$arrayOrderInsertData[$esOrderNo]['depositPolicy'] = '';
				//$arrayOrderInsertData[$esOrderNo]['mileagePolicy'] = '';
				//$arrayOrderInsertData[$esOrderNo]['statusPolicy'] ='';
				//$arrayOrderInsertData[$esOrderNo]['memberPolicy'] ='';
				//$arrayOrderInsertData[$esOrderNo]['couponPolicy'] ='';
				//$arrayOrderInsertData[$esOrderNo]['userRequestMemo'] ='';
				//$arrayOrderInsertData[$esOrderNo]['userConsultMemo'] ='';
				$arrayOrderInsertData[$esOrderNo]['adminMemo'] = str_replace('\n',chr(10),$orderDataRow[48]);
				//$arrayOrderInsertData[$esOrderNo]['orderPGLog'] ='';
				//$arrayOrderInsertData[$esOrderNo]['orderDeliveryLog'] ='';
				//$arrayOrderInsertData[$esOrderNo]['orderAdminLog'] ='';
				//$arrayOrderInsertData[$esOrderNo]['pgName'] =$orderDataRow[41];
				//$arrayOrderInsertData[$esOrderNo]['pgResultCode'] =$orderDataRow[44];
				//$arrayOrderInsertData[$esOrderNo]['pgTid'] =
				$arrayOrderInsertData[$esOrderNo]['pgAppNo'] = $orderDataRow[43];
				//$arrayOrderInsertData[$esOrderNo]['pgAppDt'] =
				//$arrayOrderInsertData[$esOrderNo]['pgCardCd'] =
				$arrayOrderInsertData[$esOrderNo]['pgSettleNm'] = '';
				$arrayOrderInsertData[$esOrderNo]['pgSettleCd'] ='';
				$arrayOrderInsertData[$esOrderNo]['pgFailReason'] ='';
				$arrayOrderInsertData[$esOrderNo]['pgCancelFl'] = ($orderDataRow[47] =='y') ? 'y' : 'n';
				$arrayOrderInsertData[$esOrderNo]['escrowSendNo'] = $orderDataRow[40];
				//$arrayOrderInsertData[$esOrderNo]['escrowDeliveryFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['escrowDeliveryDt'] ='';
				//$arrayOrderInsertData[$esOrderNo]['escrowDeliveryCd'] ='';
				//$arrayOrderInsertData[$esOrderNo]['escrowInvoiceNo'] ='';
				//$arrayOrderInsertData[$esOrderNo]['escrowConfirmFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['escrowDenyFl'] ='';
				//$arrayOrderInsertData[$esOrderNo]['fintechData'] ='';
				//$arrayOrderInsertData[$esOrderNo]['checkoutData'] ='';
				//$arrayOrderInsertData[$esOrderNo]['checksumData'] ='';
				$arrayOrderInsertData[$esOrderNo]['paymentDt'] =  $orderDataRow[35];
				$arrayOrderInsertData[$esOrderNo]['regDt'] = dateCreate($orderDataRow[1]);
				$arrayOrderInsertData[$esOrderNo]['modDt'] = 'now()';


				/*
				$arrayOrderString=array();
				foreach($esOrder as $key=>$value) {
					if ($key == 'modDt') {
						$arrayOrderString[] = "$key = " . addslashes($value);
					}
					else {
						$arrayOrderString[] = "$key = '" . addslashes($value)."'";
					}
				}
				$arrayDataQuery[] = "Insert Into es_order Set ".implode(" , ",$arrayOrderString).";";
				*/

				$esOrderInfo['orderNo'] = $esOrderNo;
				$esOrderInfo['orderName'] = $orderDataRow[3];
				$esOrderInfo['orderEmail'] = $orderDataRow[23];
				$esOrderInfo['orderPhone'] = $orderDataRow[5];
				$esOrderInfo['orderCellPhone'] = $orderDataRow[6];
				$esOrderInfo['orderZipcode'] = $orderDataRow[7];
				$esOrderInfo['orderZonecode'] = $orderDataRow[8];
				$esOrderInfo['orderAddress'] = $orderDataRow[9];
				$esOrderInfo['orderAddressSub'] = $orderDataRow[10];
				$esOrderInfo['receiverName'] = $orderDataRow[11];
				$esOrderInfo['receiverPhone'] = $orderDataRow[12];
				$esOrderInfo['receiverCellPhone'] = $orderDataRow[13];
				$esOrderInfo['receiverZipcode'] = $orderDataRow[14];
				$esOrderInfo['receiverZonecode'] = $orderDataRow[15];
				$esOrderInfo['receiverAddress'] = $orderDataRow[16];
				$esOrderInfo['receiverAddressSub'] = $orderDataRow[17];
				//$esOrderInfo['customIdNumber'] ='';
				$esOrderInfo['orderMemo'] = $orderDataRow[24];
				$esOrderInfo['regDt'] ='now()';
				$esOrderInfo['modDt'] ='now()';

				$arrayOrderInfoString=array();
				foreach($esOrderInfo as $key=>$value) {
					if ($key == 'regDt' || $key == 'modDt') {
						$arrayOrderInfoString[]="$key = ".addslashes($value);
					}
					else {
						$arrayOrderInfoString[]="$key = '".addslashes($value)."'";
					}
				}
				$arrayDataQuery[]	= "Insert Into es_orderInfo Set ".implode(" , ",$arrayOrderInfoString).";";

				$esOrderDelivery['orderNo']	=	$esOrderNo;
				$esOrderDelivery['deliverySno']	=	'';//$orderDataRow['deliveryno'];//get_order_delivery($enamooOrderDataRow['deliveryno']); �Լ� �۾� �ؾ� ��.
				$esOrderDelivery['deliveryCharge']	=	$orderDataRow[21];
				$esOrderDelivery['deliveryFixFl']	=	'price';
				$esOrderDelivery['regDt']	=	'now()';
				$esOrderDelivery['modDt']	=	'now()';
				$arrayOrderDeliveryQueryString = array();
				foreach ($esOrderDelivery as $orderDeliveryKey => $orderDeliveryValue) {
					if ($orderDeliveryKey == 'regDt' || $orderDeliveryKey == 'modDt') {
						$arrayOrderDeliveryQueryString[] = "$orderDeliveryKey = " . addslashes($orderDeliveryValue);
					}
					else {
						$arrayOrderDeliveryQueryString[] = "$orderDeliveryKey = '" . addslashes($orderDeliveryValue) . "'";
					}
				}
				$arrayDataQuery[] = "Insert Into es_orderDelivery Set " . implode(" , ", $arrayOrderDeliveryQueryString).";";
				$orderCnt++;
				if ($orderCnt % 3000 === 0) {
					echo "<script>prograss_up({$orderCnt});</script>";
				}
			}
			echo "�̳����� �ֹ� ������ ���� {$orderCnt} �� ���� �Ϸ�<br/>";

			//------------------------------------------------------
			// - Advice - �ֹ���ȣ �ӽ����̺� query ����
			//------------------------------------------------------
			
			$newOrderNoTableCreateResult = $db->query("show create table tmp_orderno");
			$newOrderNoTableCreateRow = $db->fetch($newOrderNoTableCreateResult);
			$arrayDataQuery[] = 'DROP TABLE IF EXISTS tmp_orderno;';
			$arrayDataQuery[] = $newOrderNoTableCreateRow['Create Table'] . ';';

			$selectOrderNoResult = $db->query("Select * From tmp_orderno Order By sno");
			while ($selectNewOrderNoRow = $db->fetch($selectOrderNoResult, 1)) {
				$arrayString = array();

				foreach ($selectNewOrderNoRow as $fieldName => $value) {
					$arrayString[] = "$fieldName = '" . addslashes($value) . "'";
				}
				$arrayDataQuery[] = "Insert Into tmp_orderno Set " . implode(" , ", $arrayString) . ";";
			}
			$db->query( "Optimize Table tmp_orderno;");
			//$arrayDataQuery[]	= 'Optimize Table tmp_orderno;';

		}
		
		if(@in_array("orderGoods", $relocationData) && file_exists("orderGoods.csv")) {

			$arrayDataQuery[]	= 'TRUNCATE TABLE  es_orderGoods;';
			
			//------------------------------------------------------
			// - Advice - �ֹ���ȣ ����
			//------------------------------------------------------
			$orderNo = array();
			$arrayOrderGoodsRegDt = array();
			$orderNoQuery = $db -> query("select originalOrderNo, godo5OrderNo, orderGoodsRegDt from `tmp_orderno`;");
			while($row = $db -> fetch($orderNoQuery)) {
				$orderNo[$row['originalOrderNo']] = $row['godo5OrderNo'];
				$arrayOrderGoodsRegDt[$row['originalOrderNo']] = $row['orderGoodsRegDt'];
			}
			
			//------------------------------------------------------
			// - Advice - �ӽ� ��ȯ ���̺� �귣���ȣ ����
			//------------------------------------------------------
			$arrayGodo5BrandCode = array();
			$arrayGodo5BrandCode = getTempBrandCode();
			//------------------------------------------------------

			//------------------------------------------------------
			// - Advice - �ֹ���ǰ ����
			//------------------------------------------------------
			$orderCdCountCheck = 1;
			$orderCdCountArray =array();
			$orderGoods = fopen("orderGoods.csv", 'r' );
			$resItem = fgetcsv( $orderGoods, 300000, "," );
			$firstFlag = true;
			while($orderGoodsDataRow = fgetcsv( $orderGoods, 300000, "," )) {
				$goodEsOrderNo = $arrayGodo5OrderNo[trim($orderGoodsDataRow[0])];
				
				if (!$goodEsOrderNo) continue;
				if (empty($arrayOrderInsertData[$goodEsOrderNo])) continue;
				//------------------------------------------------------
				// - Advice - es_orderGoods orderCd ���� �� ���
				//------------------------------------------------------
				$orderCdCountArray['cnt'][] = $orderCdCountCheck;
				$orderCdCountArray['orderno'][] = $goodEsOrderNo;
				$orderCdCountArray['goodsnm'][] = $orderGoodsDataRow[3];
				if($goodEsOrderNo == $orderCdCountArray['orderno'][0]) {
					$orderCdCount = count($orderCdCountArray['orderno']);
					if ($firstFlag) {
						$orderGoodsCnt = count($orderCdCountArray['orderno'])-1;

						$arrayOrderInsertData[$goodEsOrderNo]['orderGoodsNm'] = $orderCdCountArray['goodsnm'][$orderGoodsCnt];
						$arrayOrderInsertData[$goodEsOrderNo]['orderGoodsCnt'] = $orderGoodsCnt;

						$arrayOrderString=array();
						foreach($arrayOrderInsertData[$goodEsOrderNo] as $key=>$value) {
							if ($key == 'modDt') {
								$arrayOrderString[] = "$key = " . addslashes($value);
							}
							else {
								$arrayOrderString[] = "$key = '" . addslashes($value)."'";
							}
						}
						$arrayDataQuery[] = "Insert Into es_order Set ".implode(" , ",$arrayOrderString).";";
						
						//$arrayDataQuery[] = "Update es_order Set orderGoodsCnt ='" . $orderGoodsCnt . "',orderGoodsNm = '". addslashes($orderCdCountArray['goodsnm'][$orderGoodsCnt-1]) ."'  Where orderNo = '" . $orderCntOrderNo . "';";

						unset($orderCdCountArray);
						$orderCdCountArray['cnt'][] = $orderCdCountCheck;
						$orderCdCountArray['orderno'][] = $goodEsOrderNo;
						$orderCdCountArray['goodsnm'][] = $orderGoodsDataRow[3];
						$orderCdCount = '1';

						$firstFlag = false;
					}
				} else {
					$orderGoodsCnt = count($orderCdCountArray['orderno'])-1;

					$arrayOrderInsertData[$goodEsOrderNo]['orderGoodsNm'] = $orderCdCountArray['goodsnm'][$orderGoodsCnt];
					$arrayOrderInsertData[$goodEsOrderNo]['orderGoodsCnt'] = $orderGoodsCnt;

					$arrayOrderString=array();
					foreach($arrayOrderInsertData[$goodEsOrderNo] as $key=>$value) {
						if ($key == 'modDt') {
							$arrayOrderString[] = "$key = " . addslashes($value);
						}
						else {
							$arrayOrderString[] = "$key = '" . addslashes($value)."'";
						}
					}
					$arrayDataQuery[] = "Insert Into es_order Set ".implode(" , ",$arrayOrderString).";";
					
					//$arrayDataQuery[] = "Update es_order Set orderGoodsCnt ='" . $orderGoodsCnt . "',orderGoodsNm = '". addslashes($orderCdCountArray['goodsnm'][$orderGoodsCnt-1]) ."'  Where orderNo = '" . $orderCntOrderNo . "';";

					unset($orderCdCountArray);
					$orderCdCountArray['cnt'][] = $orderCdCountCheck;
					$orderCdCountArray['orderno'][] = $goodEsOrderNo;
					$orderCdCountArray['goodsnm'][] = $orderGoodsDataRow[3];
					$orderCdCount = '1';
				}

				$esOrderGoods['orderNo'] = 		$goodEsOrderNo;//�ֹ���ȣ
				$esOrderGoods['orderCd'] = 		$orderCdCount;//�ֹ��ڵ�(����)
				$esOrderGoods['orderGroupCd'] = 		'';//������ �κ� ��ҽ� �ֹ���ǰ �׷��ڵ�
				$esOrderGoods['userHandleSno'] = '';//ó���ڵ�(ȯ��/��ǰ/��ȯ)
				$esOrderGoods['handleSno'] = 		'';//ó���ڵ�(ȯ��/��ǰ/��ȯ)
				$esOrderGoods['orderStatus'] = 		$orderGoodsDataRow[5];//�ֹ�����
				$esOrderGoods['orderDeliverySno'] = 	'';//������̺�. SNO
				$esOrderGoods['invoiceCompanySno'] = 	'';//�ù�� SNO
				$esOrderGoods['invoiceNo'] = $orderGoodsDataRow[19];//�����ȣ
				//$esOrderGoods['scmNo'] = '';//SCM ID
				$esOrderGoods['commission'] = '';//���޻� ��������
				$esOrderGoods['goodsNo'] = 	$orderGoodsDataRow[1];//��ǰ��ȣ
				$esOrderGoods['goodsCd'] = 	$orderGoodsDataRow[2];//��ǰ�ڵ�
				$esOrderGoods['goodsModelNo'] = 	$orderGoodsDataRow[7];//��ǰ�𵨸�
				$esOrderGoods['goodsNm'] = 	$orderGoodsDataRow[3];//��ǰ��
				$esOrderGoods['goodsWeight'] = 	$orderGoodsDataRow[8];//��ǰ����
				$esOrderGoods['goodsCnt'] = 	$orderGoodsDataRow[6];//��ǰ����
				$esOrderGoods['goodsPrice'] = $orderGoodsDataRow[4]	;//��ǰ����
				//$esOrderGoods['taxSupplyGoodsPrice'] = 	'';//���հ��� ��ǰ ���ް�
				//$esOrderGoods['taxVatGoodsPrice'] = 		'';//���հ��� ��ǰ �ΰ���
				//$esOrderGoods['taxFreeGoodsPrice'] = 	'';//���հ��� ��ǰ �鼼
				//$esOrderGoods['divisionUseDeposit'] = 	'';//�ֹ����� �ݾ��� �Ⱥе� ��ġ��
				//$esOrderGoods['divisionUseMileage'] = 	'';//�ֹ����� �ݾ��� �Ⱥе� ���ϸ���
				//$esOrderGoods['divisionCouponOrderDcPrice'] = 	'';//�ֹ����� �ݾ��� �Ⱥе� ����
				//$esOrderGoods['divisionCouponOrderMileage'] = 	'';//�ֹ����� �ݾ��� �Ⱥе� ����
				//$esOrderGoods['addGoodsCnt'] = 	'';//�߰� ��ǰ ����
				//$esOrderGoods['addGoodsPrice'] = ''	;//�߰� ��ǰ �ݾ�
				//$esOrderGoods['optionPrice'] = ''	;//�߰� ��ǰ �ݾ�
				$esOrderGoods['paymentDt'] = $orderGoodsDataRow[23];
				$esOrderGoods['optionTextPrice'] = 	'';//�ؽ�Ʈ �ɼ� �ݾ�
				$esOrderGoods['fixedPrice'] =  '';//����
				$esOrderGoods['costPrice'] = 	'';//���԰�
				$esOrderGoods['goodsDcPrice'] = 	$orderGoodsDataRow[18];//�������αݾ�
				$esOrderGoods['memberDcPrice'] = 	$orderGoodsDataRow[17];//ȸ�����αݾ�
				//$esOrderGoods['memberOverlapDcPrice'] = 	'';//ȸ�� �׷� �ߺ� ���� �ݾ�(�߰���ǰ����)
				//$esOrderGoods['couponGoodsDcPrice'] = 	'';//��ǰ���� ���� �ݾ�(�߰���ǰ����)
				$esOrderGoods['goodsMileage'] = 	$orderGoodsDataRow[16];//��ǰ �������ϸ���(�߰���ǰ����)
				//$esOrderGoods['memberMileage'] = 	'';//ȸ�� �������ϸ���(�߰���ǰ����)
				//$esOrderGoods['couponGoodsMileage'] = 	'';//��ǰ ���� ���� ���ϸ���(�߰���ǰ����)
				//$esOrderGoods['minusStockFl'] = 	'';//���� ���� (���)
				//$esOrderGoods['minusRestoreStockFl'] = ''	;//���� ����(���)
				//$esOrderGoods['optionSno'] = 	'';//��ǰ �ɼ� �Ϸù�ȣ
				$optionMergeArray = array();
				$optionMergeSecondArray = array();
				$optionMergeAddArray = array();
				$orderItemOptionAllArray = array();
				if($orderGoodsDataRow[12]) {
					$optionMergeArray[] = "�ɼ�1";
					$optionMergeArray[]= $orderGoodsDataRow[12];
					$optionMergeArray[]= 'null';
				}
				if ($orderGoodsDataRow[13]) {
					$optionMergeSecondArray[] = "�ɼ�2";
					$optionMergeSecondArray[]= $orderGoodsDataRow[13];
					$optionMergeSecondArray[]= 'null';
				}
				if ($orderGoodsDataRow[14]) {
					$addOptFirstSettingValue = explode('^', $orderGoodsDataRow['addopt']);
					for ($addOptI = 0; $addOptI < count($addOptFirstSettingValue); $addOptI++) {
						$addOptSettingValue = explode(':', $addOptFirstSettingValue[$addOptI]);
						$optionMergeAddArray[$addOptI][] = $addOptSettingValue[0];
						$optionMergeAddArray[$addOptI][] = $addOptSettingValue[1];
						$optionMergeAddArray[$addOptI][]= 'null';
					}
				}
				$orderItemOptionAllArray = array($optionMergeArray, $optionMergeSecondArray, $optionMergeAddArray);

				$esOrderGoods['optionInfo'] =  gdOrderItemOptionEncode($orderItemOptionAllArray);//�ɼ�����
				$esOrderGoods['optionTextInfo'] = '';//�ؽ�Ʈ �ɼ�����
				//$esOrderGoods['goodsTaxInfo'] = 	'';//��ǰ �ΰ��� ����
				//$esOrderGoods['cateCd'] = 	'';//ī�װ��� �ڵ�
				$esOrderGoods['brandCd'] = 	$arrayGodo5BrandCode[$orderGoodsDataRow[10]];//�귣�� �ڵ�
				$esOrderGoods['makerNm'] = 	$orderGoodsDataRow[9];//������
				$esOrderGoods['originNm'] = 	$orderGoodsDataRow[11];//������
				//$esOrderGoods['deliveryLog'] = ''	;//��۰��÷α�
				$esOrderGoods['paymentDt'] = 	$orderGoodsDataRow[23];//�Ա�����
				$esOrderGoods['deliveryDt'] = 	$orderGoodsDataRow[20];//�������
				$esOrderGoods['deliveryCompleteDt'] = 	$orderGoodsDataRow[21];//��ۿϷ�����
				$esOrderGoods['cancelDt'] = 	$orderGoodsDataRow[22];//��ҿϷ�����
				$esOrderGoods['goodsDeliveryCollectPrice'] = 	$orderGoodsDataRow[24];//��ۺ�
				//$esOrderGoods['finishDt'] = 	'';//�Ϸ�����
				$esOrderGoods['regDt'] = 	$arrayOrderGoodsRegDt[trim($orderGoodsDataRow[0])];//�������
				$esOrderGoods['modDt'] = 	'now()';//��������

				$arrayOrderGoodsString = array();
				foreach($esOrderGoods as $key => $value) {
					if ($key == 'modDt') {
						$arrayOrderGoodsString[]="$key = ".addslashes($value);
					}
					else {
						$arrayOrderGoodsString[]="$key = '".addslashes($value)."'";
					}
				}
				$arrayDataQuery[] =  "Insert Into es_orderGoods Set ".implode(" , ",$arrayOrderGoodsString).";";
				$orderCdCountCheck++;
				$itemCnt++;
				if ($itemCnt % 10000 === 0) {
					echo "<script>itemPrograss_up({$itemCnt});</script>";
				}
			}

			//���� ū �ֹ��ڵ���� ��ǰ ���� �ֹ� ������Ʈ
			$outRoopOrderCdCount =	count($orderCdCountArray['orderno']);
			$arrayDataQuery[] = "Update es_order Set orderGoodsCnt ='" . count($orderCdCountArray['orderno']) . "',orderGoodsNm = '". addslashes($orderCdCountArray['goodsnm'][$outRoopOrderCdCount]) ."'  Where orderNo = '" . $orderCdCountArray['orderno'][$outRoopOrderCdCount] . "';";

			echo "�ֹ� ������ ������ ���� {$itemCnt} �� ���� �Ϸ�<br/>";
		}
		unset($arrayOrderInsertData);
		$arrayOrderInsertData = array();

		$arrayGetSelectTableRow = array(
			'mode'			=> 'getSelectTableRow',
			'selectTable'	=> 'es_manager',
			'orderByField'	=> 'regDt',
		);
		$getSelectTableRowReault = xmlUrlRequest('http://' . $url . '/main/relocation.php', $arrayGetSelectTableRow);
		$firstManageId = '';
		foreach ($getSelectTableRowReault->dataRow as $result) {
			if ((int)$result->result) {
				$db->query(str_replace('json', 'text', str_replace('ENGINE=InnoDB', 'ENGINE=MyISAM', str_replace('utf8mb4', 'utf8', urldecode($result->query)))));
			}
		}
		
		$firstManagerResult = $db->query("Select managerId From es_manager Where sno = '1'");
		list($firstManageId) = mysqli_fetch_row($firstManagerResult);

		if(@in_array("mileage", $relocationData) && file_exists("Mileage.csv")) {
			$arrayDataQuery[]  =  'Truncate Table es_memberMileage;';

			//------------------------------------------------------
			// - Advice - ������ ����
			//------------------------------------------------------
			$logEmoney = fopen("Mileage.csv", 'r' );
			$resItem = fgetcsv( $logEmoney, 135000, "," );
			while($mileRow = fgetcsv( $logEmoney, 135000, "," )) {
				$esMile['memNo'] = $arrayMember[$mileRow[0]];
				$esMile['managerId'] = $firstManageId;
				//$esMile['handleMode'] = '';
				//$esMile['handleCd'] = '';
				//$esMile['handleNo'] = '';
				$esMile['beforeMileage'] = $mileRow[1];
				$esMile['afterMileage'] = $mileRow[2];
				$esMile['mileage'] = $mileRow[3];
				$esMile['reasonCd'] = $mileRow[4];
				$esMile['contents'] = $mileRow[5];
				$esMile['deleteFl'] = 'complete';
				//$esMile['deleteScheduleDt'] = '';
				//$esMile['deleteDt'] = '';
				$esMile['regIp'] = '';
				$esMile['regDt'] = $mileRow[6];
				$arrayMileageString = array();
				foreach($esMile as $key=>$value) $arrayMileageString[]="$key = '".addslashes($value)."'";
				$arrayDataQuery[] = "Insert Into es_memberMileage Set ".implode(" , ",$arrayMileageString);

				$emoneyCnt++;
				echo "<script>emoneyPrograss_up({$emoneyCnt});</script>";

			}
				echo "������ ������ ���� ���� {$emoneyCnt} �ǿϷ�<br/>";
			$arrayDataQuery[] = "Insert Into es_memberMileage (memNo, handleMode, reasonCd, deleteFl, afterMileage, mileage, contents, regDt) SELECT memNo, 'm' as handleMode, '01005011' as reasonCd, 'n' as deleteFl, mileage as afterMileage, mileage, '������ ���� : ��밡�� �����ݰ� ������ ���� ����ȭ ���� �߰� �α�' as memo, now() as regDt FROM `es_member` WHERE mileage > 0;";

			$arrayDataQuery[] = "Update es_memberMileage set deleteFl = 'n' WHERE mileage < 0;";

			$arrayDataQuery[] = "Optimize Table es_memberMileage;";
			$arrayDataQuery[] = "Optimize Table es_orderDelivery;";
			$arrayDataQuery[] = "Optimize Table es_orderInfo;";
			$arrayDataQuery[] = "Optimize Table es_order;";
			$arrayDataQuery[] = "Optimize Table es_orderGoods;";
			$arrayDataQuery[] = "Optimize Table tmp_orderno;";
			$arrayDataQuery[] = "UPDATE `es_orderGoods` a set orderDeliverySno = (Select sno From es_orderDelivery b Where a.orderNo = b.orderNo);";
		}
	if($arrayDataQuery) {
		if (is_file($dumpFileName . '.sql')) {
			unlink($dumpFileName . '.sql');
		}
		dumpSqlFileSet ($dumpFileName, $arrayDataQuery);
	} else {
		echo "<script>alert('�����Ͱ� ���ų� ���õ��� �ʾҽ��ϴ�.');</script>";
	}

} else {
	?>
<html>
	<head>
		<title>:: Ÿ�� -> ������5 �ֹ� ���� ��� ::</title>
		<link href="http://relocation.godo.co.kr/module/_import/jqueryui/css/south-street/jquery-ui-1.9.2.custom.css" rel="stylesheet">
		<script src="http://relocation.godo.co.kr/module/_import/jqueryui/js/jquery-1.8.3.js"></script>
		<script src="http://relocation.godo.co.kr/module/_import/jqueryui/js/jquery-ui-1.9.2.custom.js"></script>
		<style type="text/css">
			body, header, h1, article, table, tr, td, div {
				font-family:'����', 'dotum', 'gulim';
				padding:0;
				margin:0;
				font-size:13px;
			}
		</style>
	</head>
	<body>
	<header><h1>������ 5 Ÿ�� �ֹ� ���� ��� </h1></header>
	<form name="frmMain" method="POST" action="./autoOrder.php">
		<div style="width: 600px;margin:0 auto;padding-top:20px;" class="accordion">

			<h3>����</h3>
			<table cellspacing="0" cellpadding="0" id="domainSetting">
				<colgroup>
					<col width="250px" />
					<col width="350px" />
				</colgroup>
				<tbody>
				<tr>
					<th align="left">��� ������ : </th>
					<td><input type="text" name="afterUrl" value="hym19871.godo.co.kr"/>ex) test.co.kr</td>
				</tr>
				<tr>
					<th align="left">���̱׷��̼� ���� ���ϸ�</th>
					<td><input type="text" name="dumpFileName" value="dataOrderQuery"/> .sql</td>
				</tr>
				<tr>
					<th align="left">�ֹ� ���� ��� �ٿ�ε� : </th>
					<td><input type="button" name="orderXlsDown" onclick="location.href='http://relocation.godo.co.kr/relocation_godo5/order/order.zip'" value="��� �ٿ�ε�"></td>
				</tr>
				<tr>
					<th align="left">�ֹ� üũ ���� Ȯ�� : </th>
					<td><input type="button" name="orderXlsDown"  onclick="layerOrderCheck();" value="�ֹ� üũ ����"></td>
				</tr>
				</tbody>
				<tfoot>
				</tfoot>
			</table>
		</div>
		<div style="width: 600px;margin:0 auto;padding-top:20px;" class="accordion">
			<h3>������</h3>
			<table cellspacing="0" cellpadding="0" id="domainSetting">
				<colgroup>
					<col width="250px" />
					<col width="350px" />
				</colgroup>
				<tbody>
				<tr>
					<th align="left">��ü üũ </th>
					<td><label><input type="checkbox" name="relocationAllCheck" class="relocationAllCheck" value="All" /> ��ü üũ</label> </td>
				</tr>
				<tr>
					<th align="left">�ֹ� ������ : </th>
					<td><label><input type="checkbox" name="relocationData[]" class="relocationData" value="order" /> �ֹ� (order.csv) <?=lineDataNum('order');?></label></td>
				</tr>
				<tr>
					<th align="left">�ֹ� ��ǰ ������ : </th>
					<td><label><input type="checkbox" name="relocationData[]" class="relocationData" value="orderGoods" /> �ֹ� ��ǰ (orderGoods.csv) <?=lineDataNum('orderGoods');?></label></td>
				</tr>
				<tr>
					<th align="left">������ ���� ������ : </th>
					<td><label><input type="checkbox" name="relocationData[]" class="relocationData" value="mileage" /> ���ϸ��� (Mileage.csv) <?=lineDataNum('Mileage');?></label></td>
				</tr>
				<tr>
					<th align="left"><input type="hidden" name="m" value="start">
						<input type="submit" name="formSubmit" value="������ ��ȯ" /></th>
					<td></td>
				</tr>
				</tbody>
				<tfoot>
				</tfoot>
			</table>
		</div>
		<div id="layerOrderDiv" style="position: absolute; border: 2px solid rgb(59, 171, 238); z-index: 99999999; display: none; padding: 0px; height: 600px; width: 1000px; top: 220.5px; left: 340px; background-color: rgb(255, 255, 255);">
			<iframe src="http://relocation.godo.co.kr/relocation_godo5/order/orderCheckLayer.php" height="100%" width="100%"></iframe>
			<input type="button" name="closeLayer" onclick="layerOrderCheck();" value="�ݱ�">
		</div>
	<script type="text/javascript">
		$(document).ready(function(){
			$( ".accordion" ).accordion({
				heightStyle: "content"
			});
			$('.relocationAllCheck').click(function(){
				if ($(this).is(':checked')) {
					$('.relocationData').prop('checked','checked');
				}
				else {
					$('.relocationData').prop('checked',false);
				}
			});
		});
		function layerOrderCheck(){
			$('#layerOrderDiv').toggle();
		}
	</script>
</html>
<?php
}
/**
 * Date = ���� �۾���(2016.04.15)
 * ETC = ������ 5 Ÿ������ ���
 * Developer = ������
 */
?>